// Foo.js
