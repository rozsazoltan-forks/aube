// foo.js
