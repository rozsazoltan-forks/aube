# @pnpm.e2e/aube-test-failing-install

Synthetic fixture for aube's lifecycle_scripts.bats. Its install script always exits 1 — used to verify aube retries on the next install instead of treating the prior failure as a successful state.
